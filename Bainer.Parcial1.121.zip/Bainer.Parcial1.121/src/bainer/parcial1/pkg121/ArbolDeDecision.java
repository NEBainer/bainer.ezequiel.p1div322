package bainer.parcial1.pkg121;


public class ArbolDeDecision extends Modelo implements Entrenable{
    private String criterioDeDivision;

    public ArbolDeDecision(String nombre, String laboratorio, TipoDatos tipoDeDatos, String criterioDeDivision) {
        super(nombre, laboratorio, tipoDeDatos);
        this.criterioDeDivision = criterioDeDivision;
    }

    public String getCriterioDeDivision() {
        return criterioDeDivision;
    }
    
    @Override
    public void entrenar(){
        System.out.println("El arbol de decision " + getNombre()+ " entrena rapido debido a sus constantes divisiones de ramas");
    }
    
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Nombre del modelo: %s \nLaboratorio: %s \nTipo de datos: %s \nCriterio de division: %s "+ "", getNombre(), getLaboratorio(), getTipoDeDatos(),getCriterioDeDivision()));
        return sb.toString();
    }

}
