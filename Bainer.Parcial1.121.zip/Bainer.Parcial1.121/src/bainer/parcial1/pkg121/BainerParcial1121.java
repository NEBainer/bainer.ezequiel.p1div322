
package bainer.parcial1.pkg121;


public class BainerParcial1121 {


    public static void main(String[] args) throws ModeloRepetido {
        CentroDeEntrenamiento centro = new CentroDeEntrenamiento("Centro");
        hardcodearCentro(centro);
        centro.mostrarModelos();
        centro.entrenarModelos();
        centro.filtrarPorTipoDatos(TipoDatos.DATOS_NUMERICOS); 
    }
    public static void hardcodearCentro(CentroDeEntrenamiento c) throws ModeloRepetido{
        try{
            c.agregarModelo(new RedNeuronal("ClasificadorImagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 10));
        } catch (ModeloRepetido e){
            System.out.println( "Error"  + e.getMessage());
        }
        try{
            c.agregarModelo(new RedNeuronal("ClasificadorImagenes", "Lab2", TipoDatos.DATOS_NUMERICOS, 10));
        } catch (ModeloRepetido e){
            System.out.println( "Error"  + e.getMessage());
        }
        
        try{
            c.agregarModelo(new AlgoritmoGenetico("Algoritmo 1", "Lab2", TipoDatos.DATOS_NUMERICOS, 15));
        } catch (ModeloRepetido e){
            System.out.println( "Error"  + e.getMessage());
        }
        
        try{
            c.agregarModelo(new ArbolDeDecision("Arbolito 1", "Lab3", TipoDatos.DATOS_NUMERICOS, "Se divide por dos"));
        } catch (ModeloRepetido e){
            System.out.println( "Error"  + e.getMessage());
        }
    }
}
