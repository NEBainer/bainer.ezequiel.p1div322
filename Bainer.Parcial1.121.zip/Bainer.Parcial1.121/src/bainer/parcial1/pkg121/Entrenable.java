
package bainer.parcial1.pkg121;

public interface Entrenable {
    public void entrenar();
}
