package bainer.parcial1.pkg121;


public class ModeloRepetido extends Exception{
    public ModeloRepetido(String mensaje) {
        super(mensaje);
    }
}
