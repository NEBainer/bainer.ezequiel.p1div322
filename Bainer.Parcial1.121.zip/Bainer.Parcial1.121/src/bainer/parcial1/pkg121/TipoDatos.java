
package bainer.parcial1.pkg121;

public enum TipoDatos {
    DATOS_NUMERICOS,
    DATOS_TEXTUALES
}
