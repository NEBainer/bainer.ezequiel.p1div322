package bainer.parcial1.pkg121;


public class AlgoritmoGenetico extends Modelo{
    private static final int TASA_MUTACION_IDEAL = 50;
    private static final int TASA_MUTACION_MIN = 1;
    private double tasaMutacion;

    public AlgoritmoGenetico(String nombre, String laboratorio, TipoDatos tipoDeDatos, double tasaMutacion) {
        super(nombre, laboratorio, tipoDeDatos);
        verificarTasaMutacion(tasaMutacion);
        this.tasaMutacion = tasaMutacion;
    }
    
    private void verificarTasaMutacion(double tasa){
        if(tasa < TASA_MUTACION_MIN || tasa > TASA_MUTACION_IDEAL){
            throw new IllegalArgumentException("La tasa de mutacion debe ser mayor a cero y menor que 50\n");
        }
    }
    
    public double getTasaMutacion(){
        return tasaMutacion;
    }
    
    @Override
    public String toString(){
        return super.toString() + "Tasa de mutacion: " + tasaMutacion + "\n";
    }

}
