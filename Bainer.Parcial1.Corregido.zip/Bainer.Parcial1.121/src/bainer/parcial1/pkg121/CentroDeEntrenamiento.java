package bainer.parcial1.pkg121;

import java.util.ArrayList;
import java.util.List;


public class CentroDeEntrenamiento{
    private String nombre;
    private List<Modelo> modelos;
    public CentroDeEntrenamiento(String nombre) {
        this.nombre = nombre;
        modelos = new ArrayList<>();
    }
    
    public void agregarModelo(Modelo modelo) throws ModeloRepetido{
    if (modelo != null) {
        for (Modelo e : modelos) {
            if (e.getNombre().equals(modelo.getNombre())&& e.getLaboratorio().equals(modelo.getLaboratorio())) {
                throw new ModeloRepetido("El modelo " + modelo.getNombre() + " ya existe.\n");
            }
        }
        modelos.add(modelo);
    }
}
    
    public void mostrarModelos(){
        for(Modelo modelo: modelos){
            System.out.println(modelo);
        }
    }
    
    public void entrenarModelos() {
    for (Modelo modelo: modelos) {
        if (modelo instanceof Entrenable) {
            Entrenable entrenable = (Entrenable) modelo;
            entrenable.entrenar();
        } else {
            System.out.println("No se pudo entrenar al modelo " + modelo.getNombre() + " ya que no es entrenable\n");
        }
    }
}
    
    public List filtrarPorTipoDatos(TipoDatos tipo) {
        System.out.println("Modelos con el tipo de dato: " + tipo + ".");
        for (Modelo modelo : modelos) {
            if ((modelo.getTipoDeDatos()).equals(tipo)) {
                System.out.println("-" + modelo.getNombre() + ".");
            }
        } return modelos;
    }


}
