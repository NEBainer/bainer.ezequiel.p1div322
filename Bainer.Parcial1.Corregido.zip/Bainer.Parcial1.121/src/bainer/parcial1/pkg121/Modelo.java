package bainer.parcial1.pkg121;

import java.util.Objects;


public abstract class Modelo{
    private String nombre;
    private String laboratorio;
    private TipoDatos tipoDeDatos;

    public Modelo(String nombre, String laboratorio, TipoDatos tipoDeDatos) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.tipoDeDatos = tipoDeDatos;
    }
    
    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Nombre del modelo: %s \nLaboratorio: %s \nTipo de datos: %s"+ "\n", getNombre(), getLaboratorio(), getTipoDeDatos()));
        return sb.toString();
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public TipoDatos getTipoDeDatos() {
        return tipoDeDatos;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Modelo other = (Modelo) obj;
        return (this.nombre.equals(other.nombre) && this.laboratorio.equals(other.laboratorio));
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, laboratorio); 
    }

}
