package bainer.parcial1.pkg121;


public class RedNeuronal extends Modelo implements Entrenable{
    private static final int CANT_MAX_CAPAS = 50;
    private static final int CANT_MIN_CAPAS = 1;
    private int cantDeCapas;

    public RedNeuronal(String nombre, String laboratorio, TipoDatos tipoDeDatos, int cantDeCapas) {
        super(nombre, laboratorio, tipoDeDatos);
        verificarCantDeCapas(cantDeCapas);
        this.cantDeCapas = cantDeCapas;
    }
    
    private void verificarCantDeCapas(int capas){
        if(capas < CANT_MIN_CAPAS || capas > CANT_MAX_CAPAS){
            throw new IllegalArgumentException("La cantidad de capas introducidas es invalidas\n");
        }
    }

    public int getCantDeCapas() {
        return cantDeCapas;
    }
    
    @Override
    public String toString(){
        return super.toString() + "Cantidad de capas: " + cantDeCapas + "\n";
    }
    
    @Override
    public void entrenar(){
        System.out.println("La red neuronal " + getNombre()+ " entrena gracias a sus capas\n");
    }
    
    
    
    

}
