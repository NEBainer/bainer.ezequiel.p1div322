
package bainerrecuperatorio1.pkg321;

import java.time.LocalDate;


public class BainerRecuperatorio1321 {


    public static void main(String[] args) {
        Excavacion excava = new Excavacion("La Quiaca");
        harcodearExcavacion(excava);
        excava.analizarHallazgos();
        excava.filtrarHallazgos(EpocaHistorica.PRECOLOMBINA);
        excava.filtrarPorEstadoConservacion(1, 9);
        
        
    }
    public static void harcodearExcavacion(Excavacion e) throws HallazgoRepetido{
        try{
            e.registrarNuevosHallazgos(new RestosFosiles("Brasil", LocalDate.of(2023, 6, 15), 8, "Tiranusaurio", true));
            e.registrarNuevosHallazgos(new RestosFosiles("Brasil", LocalDate.of(2023, 6, 15), 8, "velociraptor", true));
            e.registrarNuevosHallazgos(new ConstruccionesRuinosas("Brasil", LocalDate.of(2023, 6, 15), 8, TipoEdificacion.TEMPLO, EpocaHistorica.MODERNA));
        } catch (HallazgoRepetido e){
            System.out.println("Error: "+ e.getMessage());
        }
    }
    
}
