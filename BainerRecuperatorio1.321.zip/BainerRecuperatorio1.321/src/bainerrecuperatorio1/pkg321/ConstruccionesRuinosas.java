package bainerrecuperatorio1.pkg321;

import java.time.LocalDate;


public class ConstruccionesRuinosas extends Hallazgo implements Restaurable{
    private TipoEdificacion tipoDeEdificacion;
    private EpocaHistorica epocaHistorica;

    public ConstruccionesRuinosas(String sitio, LocalDate fechaDescubrimiento, int estadoConservacion, TipoEdificacion tipoDeEdificacion, EpocaHistorica epocaHistorica) {
        super(sitio, fechaDescubrimiento, estadoConservacion);
        this.tipoDeEdificacion = tipoDeEdificacion;
        this.epocaHistorica = epocaHistorica;
    }

    public TipoEdificacion getTipoDeEdificacion() {
        return tipoDeEdificacion;
    }

    public EpocaHistorica getEpocaHistorica() {
        return epocaHistorica;
    }
    
    @Override
    public String toString() {
        return super.toString() +
                ", Tipo de Edificacion: "+ tipoDeEdificacion +
                ", Epoca Historica: " + epocaHistorica;
    }
    
    @Override
    public void restaurarHallazgo(){
        System.out.println("Se restaura la construccion de un " + getTipoDeEdificacion()+ ", de la epoca " + getEpocaHistorica());
    }

}
