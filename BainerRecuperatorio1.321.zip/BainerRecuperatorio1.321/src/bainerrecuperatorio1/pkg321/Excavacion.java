package bainerrecuperatorio1.pkg321;

import java.util.ArrayList;
import java.util.List;


public class Excavacion{
    private String lugarDeExcavacion;
    private List<Hallazgo> hallazgos;

    public Excavacion(String lugarDeExcavacion) {
        this.lugarDeExcavacion = lugarDeExcavacion;
        hallazgos = new ArrayList<>();
    }
    
    public void registrarNuevosHallazgos(Hallazgo hallazgo) throws HallazgoRepetido{
        if(hallazgo != null){
            for(Hallazgo h: hallazgos){
                if(h.getFechaDescubrimiento().equals(hallazgo.getFechaDescubrimiento())&& h.getSitio().equals(hallazgo.getSitio())){
                    throw new HallazgoRepetido("Ya hay una hallazgo realizado en la fecha " + hallazgo.getFechaDescubrimiento()+
                    "en el sitio " + hallazgo.getSitio());
                }
            }
            hallazgos.add(hallazgo);
        }
    }
    
    public void listarHallazgos(){
        for(Hallazgo hallazgo: hallazgos){
            System.out.println(hallazgo);
        }
    }
    
    public void analizarHallazgos(){
        for(Hallazgo hallazgo: hallazgos){
            if(hallazgo instanceof Analizable){
                Analizable analizable = (Analizable) hallazgo;
                analizable.analizarHallazgo();
            } else {
                System.out.println("No se pudo analizar el hallazgo" + hallazgo.getId() + " por que es una construccion");
            }
        }
    }
    
    public void restaurarHallazgos(){
        for(Hallazgo hallazgo: hallazgos){
            if(hallazgo instanceof Restaurable){
                Restaurable restaurable = (Restaurable) hallazgo;
                restaurable.restaurarHallazgo();
            } else {
                System.out.println("No se pudo restaurar el hallazgo" + hallazgo.getId() + " por que no es una construccion. Es un fosil o herramienta antigua");
            }
        }
    }
    
    public List<ConstruccionesRuinosas> filtrarHallazgos(EpocaHistorica epocaHistorica) {
    List<ConstruccionesRuinosas> hallazgosFiltrados = new ArrayList<>();

    System.out.println("Hallazgos de la Época Histórica: " + epocaHistorica + ".");

    for (Hallazgo hallazgo : hallazgos) {
        if (hallazgo instanceof ConstruccionesRuinosas) {
            ConstruccionesRuinosas construccion = (ConstruccionesRuinosas) hallazgo;

            if (construccion.getEpocaHistorica().equals(epocaHistorica)) {
                hallazgosFiltrados.add(construccion);
                System.out.println(construccion); 
            }
        } 
    }return hallazgosFiltrados;
    }
    
    public List<Hallazgo> filtrarPorEstadoConservacion(int desde, int hasta) {
    List<Hallazgo> hallazgosFiltrados = new ArrayList<>();

    System.out.println("Hallazgos con estado de conservación entre " + desde + " y " + hasta + ":");

    for (Hallazgo hallazgo : hallazgos) {
        int estado = hallazgo.getEstadoConservacion();
        if (estado >= desde && estado <= hasta) {
            hallazgosFiltrados.add(hallazgo);
            System.out.println(hallazgo); 
        }

    }return hallazgosFiltrados;
    }

}
