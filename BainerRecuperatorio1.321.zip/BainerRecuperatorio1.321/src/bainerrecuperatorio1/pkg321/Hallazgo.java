package bainerrecuperatorio1.pkg321;


import java.time.LocalDate;
import java.util.Objects;

public abstract class Hallazgo {
    private static int contadorIds = 50000;
    private int id;
    private String sitio;
    private LocalDate fechaDescubrimiento;
    private int estadoConservacion; // de 1 a 10

    public Hallazgo(String sitio, LocalDate fechaDescubrimiento, int estadoConservacion) {
        this.id = contadorIds++;
        this.sitio = sitio;
        this.fechaDescubrimiento = fechaDescubrimiento;
        this.estadoConservacion = estadoConservacion;
    }

    public int getId() {
        return id;
    }

    public String getSitio() {
        return sitio;
    }

    public LocalDate getFechaDescubrimiento() {
        return fechaDescubrimiento;
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }

    @Override
    public String toString() {
        return "Hallazgo ID: " + id +
               ", Sitio: " + sitio +
               ", Fecha: " + fechaDescubrimiento +
               ", Estado de conservación: " + estadoConservacion;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Hallazgo other = (Hallazgo) obj;
        return (this.sitio.equals(other.sitio) && this.fechaDescubrimiento.equals(other.fechaDescubrimiento));
    }

    @Override
    public int hashCode() {
        return Objects.hash(sitio, fechaDescubrimiento);
    }
}