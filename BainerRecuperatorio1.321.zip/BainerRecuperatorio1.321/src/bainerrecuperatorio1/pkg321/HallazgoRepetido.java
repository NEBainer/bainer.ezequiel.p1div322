package bainerrecuperatorio1.pkg321;


public class HallazgoRepetido extends Exception{
    public HallazgoRepetido(String mensaje) {
        super(mensaje);
    }
}
