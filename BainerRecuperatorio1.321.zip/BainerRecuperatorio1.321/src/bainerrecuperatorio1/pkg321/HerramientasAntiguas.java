package bainerrecuperatorio1.pkg321;

import java.time.LocalDate;


public class HerramientasAntiguas extends Hallazgo implements Analizable{
    private String material;
    private String usoProbable;

    public HerramientasAntiguas(String sitio, LocalDate fechaDescubrimiento, int estadoConservacion, String material, String usoProbable) {
        super(sitio, fechaDescubrimiento, estadoConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    public String getMaterial() {
        return material;
    }

    public String getUsoProbable() {
        return usoProbable;
    }
    
    @Override
    public String toString() {
        return super.toString() +
                ", Material: "+ material +
                ", Uso Probable: " + usoProbable;
    }
    
    @Override
    public void analizarHallazgo(){
        System.out.println("Se analiza la herramienta antigua hecha de " + getMaterial());
    }

}
