/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bainerrecuperatorio1.pkg321;

/**
 *
 * @author ezzeb
 */
public interface Restaurable {
    public void restaurarHallazgo();
}
