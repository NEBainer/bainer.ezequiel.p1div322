package bainerrecuperatorio1.pkg321;

import java.time.LocalDate;


public class RestosFosiles extends Hallazgo implements Analizable{
    private String especieDescubierta;
    private boolean esqueletoCompleto;

    public RestosFosiles(String sitio, LocalDate fechaDescubrimiento, int estadoConservacion, String especieDescubierta, boolean esqueletoCompleto) {
        super(sitio, fechaDescubrimiento, estadoConservacion);
        this.especieDescubierta = especieDescubierta;
        this.esqueletoCompleto = esqueletoCompleto;
    }

    public String getEspecieDescubierta() {
        return especieDescubierta;
    }

    public boolean isEsqueletoCompleto() {
        return esqueletoCompleto;
    }

    @Override
    public String toString() {
        return super.toString() +
                ", Especie: "+ especieDescubierta +
                ", Esqueleto completo: " + esqueletoCompleto;
    }
    
    @Override
    public void analizarHallazgo(){
        System.out.println("Se analiza el fosil de la especie " + getEspecieDescubierta());
    }
    
    

}
